import { useState } from "react";
import StudentLayout from "../../components/student/StudentLayout";
import api from "../../lib/api";
import { Award, Loader2, ChevronDown, ChevronUp } from "lucide-react";

export default function Scholarships() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState({});

  const fetch = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api.post("/ai/scholarships");
      setResult(res.data.scholarships);
    } catch (err) {
      setError(err.response?.data?.error || "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  // Parse the AI markdown-style response into sections per scholarship
  const sections = result
    ? result.split(/\n(?=\d+\.|#{1,3}\s|\*\*\d)/).filter(s => s.trim())
    : [];

  return (
    <StudentLayout>
      <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Scholarship Recommendations</h1>
      <p className="text-sm text-gray-500 mb-6">
        AI-matched scholarships based on your academic profile, stream, and state.
      </p>

      {!result && !loading && (
        <div className="bg-white border border-gray-100 rounded-2xl p-8 text-center mb-6">
          <Award size={36} className="mx-auto text-primary-400 mb-4" />
          <h2 className="font-display font-bold text-gray-900 mb-2">Find scholarships you qualify for</h2>
          <p className="text-sm text-gray-500 mb-6 max-w-sm mx-auto">
            Based on your 12th percentage, stream, state, and preferred course, we'll suggest
            real Indian scholarships you can apply for.
          </p>
          <button
            onClick={fetch}
            className="bg-primary-600 text-white px-6 py-2.5 rounded-lg font-semibold text-sm hover:bg-primary-700 transition"
          >
            Find my scholarships
          </button>
        </div>
      )}

      {loading && (
        <div className="bg-white border border-gray-100 rounded-2xl p-10 text-center">
          <Loader2 size={28} className="animate-spin text-primary-500 mx-auto mb-3" />
          <p className="text-sm text-gray-500">Finding scholarships matched to your profile…</p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-100 rounded-2xl p-5 mb-4">
          <p className="text-sm text-red-600">{error}</p>
          <p className="text-xs text-red-400 mt-1">
            Make sure your 12th percentage is saved in your profile.
          </p>
        </div>
      )}

      {result && (
        <>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-gray-500">{sections.length} scholarships found for your profile</p>
            <button
              onClick={fetch}
              className="text-xs text-primary-600 hover:underline"
            >
              Refresh
            </button>
          </div>

          {sections.length > 0 ? (
            <div className="space-y-3">
              {sections.map((section, i) => {
                const lines = section.trim().split("\n").filter(Boolean);
                const heading = lines[0].replace(/^[#*\d.\s]+/, "").trim();
                const body = lines.slice(1).join("\n").trim();
                const isOpen = expanded[i] ?? true;

                return (
                  <div key={i} className="bg-white border border-gray-100 rounded-2xl overflow-hidden">
                    <button
                      onClick={() => setExpanded(prev => ({ ...prev, [i]: !isOpen }))}
                      className="w-full flex items-center justify-between px-5 py-4 text-left"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 rounded-md bg-primary-50 text-primary-600 flex items-center justify-center text-xs font-bold shrink-0">
                          {i + 1}
                        </div>
                        <span className="font-display font-bold text-sm text-gray-900">{heading || `Scholarship ${i + 1}`}</span>
                      </div>
                      {isOpen ? <ChevronUp size={15} className="text-gray-400" /> : <ChevronDown size={15} className="text-gray-400" />}
                    </button>
                    {isOpen && body && (
                      <div className="px-5 pb-4 text-sm text-gray-600 whitespace-pre-wrap border-t border-gray-50 pt-3">
                        {body}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            // Fallback: just render the raw text if parsing produces no sections
            <div className="bg-white border border-gray-100 rounded-2xl p-6">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap font-sans">{result}</pre>
            </div>
          )}
        </>
      )}
    </StudentLayout>
  );
}