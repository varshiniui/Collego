import { useState } from "react";
import StudentLayout from "../../components/student/StudentLayout";
import api from "../../lib/api";
import { BookOpen, Loader2, Target } from "lucide-react";

const PHASES = ["IMMEDIATE", "SHORT TERM", "MEDIUM TERM", "LONG TERM"];
const PHASE_LABELS = {
  "IMMEDIATE": "Next 3 months",
  "SHORT TERM": "First year",
  "MEDIUM TERM": "2nd & 3rd year",
  "LONG TERM": "Final year & beyond",
};
const PHASE_COLORS = {
  "IMMEDIATE":   "bg-primary-50 text-primary-700 border-primary-100",
  "SHORT TERM":  "bg-emerald-50 text-emerald-700 border-emerald-100",
  "MEDIUM TERM": "bg-amber-50 text-amber-700 border-amber-100",
  "LONG TERM":   "bg-purple-50 text-purple-700 border-purple-100",
};

export default function LearningPath() {
  const [careerGoal, setCareerGoal] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const generate = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await api.post("/ai/learning-path", { career_goal: careerGoal });
      setResult(res.data.learning_path);
    } catch (err) {
      setError(err.response?.data?.error || "Something went wrong. Try again.");
    } finally {
      setLoading(false);
    }
  };

  // Parse the AI response into phase sections
  const parsedPhases = result
    ? PHASES.map(phase => {
        const regex = new RegExp(
          `${phase}[^\n]*\n([\s\S]*?)(?=${PHASES.filter(p => p !== phase).map(p => `${p}[^\n]*\n`).join("|")}|$)`,
          "i"
        );
        const match = result.match(regex);
        return {
          phase,
          content: match ? match[1].trim() : null,
        };
      }).filter(p => p.content)
    : [];

  return (
    <StudentLayout>
      <h1 className="font-display text-2xl font-bold text-gray-900 mb-1">Learning Path</h1>
      <p className="text-sm text-gray-500 mb-6">
        A personalised roadmap from now through placement, built around your profile and career goal.
      </p>

      {!result && !loading && (
        <div className="bg-white border border-gray-100 rounded-2xl p-8 mb-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-10 h-10 rounded-xl bg-primary-50 flex items-center justify-center">
              <Target size={20} className="text-primary-600" />
            </div>
            <div>
              <h2 className="font-display font-bold text-gray-900">What's your career goal?</h2>
              <p className="text-xs text-gray-400">Optional — leave blank to get a general path based on your profile</p>
            </div>
          </div>
          <input
            value={careerGoal}
            onChange={e => setCareerGoal(e.target.value)}
            onKeyDown={e => e.key === "Enter" && generate()}
            placeholder="e.g. Software Engineer at a product company, Data Scientist, Civil Services…"
            className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200 mb-4"
          />
          <button
            onClick={generate}
            className="w-full bg-primary-600 text-white py-2.5 rounded-lg font-semibold text-sm hover:bg-primary-700 transition"
          >
            Generate my learning path
          </button>
        </div>
      )}

      {loading && (
        <div className="bg-white border border-gray-100 rounded-2xl p-10 text-center">
          <Loader2 size={28} className="animate-spin text-primary-500 mx-auto mb-3" />
          <p className="text-sm text-gray-500">Building your personalised learning path…</p>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-100 rounded-2xl p-5 mb-4">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {result && (
        <>
          <div className="flex items-center justify-between mb-5">
            {careerGoal && (
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Target size={14} className="text-primary-500" />
                Goal: <span className="font-medium">{careerGoal}</span>
              </div>
            )}
            <button
              onClick={() => { setResult(null); setError(null); }}
              className="text-xs text-primary-600 hover:underline ml-auto"
            >
              Regenerate
            </button>
          </div>

          {parsedPhases.length > 0 ? (
            <div className="space-y-4">
              {parsedPhases.map(({ phase, content }) => (
                <div key={phase} className={`border rounded-2xl overflow-hidden ${PHASE_COLORS[phase]}`}>
                  <div className="px-5 py-3 border-b border-current border-opacity-20">
                    <p className="text-xs font-semibold uppercase tracking-wide opacity-70">{PHASE_LABELS[phase]}</p>
                    <h3 className="font-display font-bold text-base">{phase.charAt(0) + phase.slice(1).toLowerCase()}</h3>
                  </div>
                  <div className="px-5 py-4 bg-white text-sm text-gray-700 whitespace-pre-wrap">
                    {content}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            // Fallback if parsing finds no phase headings
            <div className="bg-white border border-gray-100 rounded-2xl p-6">
              <pre className="text-sm text-gray-700 whitespace-pre-wrap font-sans">{result}</pre>
            </div>
          )}
        </>
      )}
    </StudentLayout>
  );
}